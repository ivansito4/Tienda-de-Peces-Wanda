class Pez {
    constructor(nombre,nombreCientifico,foto,precio,alimentacion,comportamiento,temperatura,salinidad,ph,url){
        this.nombre=nombre;
        this.nombreCientifico=nombreCientifico;
        this.foto=foto;
        this.precio=precio;
        this.alimentacion=alimentacion;
        this.comportamiento=comportamiento;
        this.temperatura=temperatura;
        this.salinidad=salinidad;
        this.ph=ph;
        this.url=url;
    }
}
